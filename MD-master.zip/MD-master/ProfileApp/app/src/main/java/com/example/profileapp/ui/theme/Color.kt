package com.example.profileapp.ui.theme

import androidx.compose.ui.graphics.Color

val Green80 = Color(0xFFD0E6E0) // Новый цвет
val GreenGrey80 = Color(0xFFB2D7D4) // Новый цвет
val LightGreen80 = Color(0xFFC8E6C9) // Новый цвет

val Green40 = Color(0xFF5D8A78) // Новый цвет
val GreenGrey40 = Color(0xFF4C7B6A) // Новый цвет
val LightGreen40 = Color(0xFF3EBD8A) // Новый цвет
